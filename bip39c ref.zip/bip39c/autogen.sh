aclocal \
&& autoreconf --install \
&& automake --add-missing
